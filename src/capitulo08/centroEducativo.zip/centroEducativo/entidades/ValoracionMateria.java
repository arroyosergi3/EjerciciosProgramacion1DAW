package capitulo08.centroEducativo.entidades;

public class ValoracionMateria {

	private Estudiante est;
	private Profesor prof;
	private Materia mat;
	private int valoracion;
	
	
	
	public Estudiante getEst() {
		return est;
	}
	public void setEst(Estudiante est) {
		this.est = est;
	}
	public Profesor getProf() {
		return prof;
	}
	public void setProf(Profesor prof) {
		this.prof = prof;
	}
	public Materia getMat() {
		return mat;
	}
	public void setMat(Materia mat) {
		this.mat = mat;
	}
	public int getValoracion() {
		return valoracion;
	}
	public void setValoracion(int valoracion) {
		this.valoracion = valoracion;
	}
	
	
	
	

	
}
